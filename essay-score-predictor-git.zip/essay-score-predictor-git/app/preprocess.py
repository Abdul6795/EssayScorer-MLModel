import re

def clean_essay(text):
    """
    Clean the essay text by removing unwanted characters, lowercasing, etc.
    """
    text = text.lower()
    text = re.sub(r'\n', ' ', text)
    text = re.sub(r'[^\w\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text
