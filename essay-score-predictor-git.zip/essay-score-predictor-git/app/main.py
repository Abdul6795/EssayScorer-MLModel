from fastapi import FastAPI
import joblib
import os
from app.modelling import get_bert_embeddings
import torch
import numpy as np
app = FastAPI()

@app.post("/predict/")
def predict_essay_score(essay: str):
    # Load the trained model, tokenizer, and BERT model
    model = joblib.load('best_model.pkl')
    tokenizer = joblib.load('tokenizer.pkl')
    bert_model = joblib.load('bert_model.pkl')

    # Clean and generate embeddings
    inputs = tokenizer([essay], return_tensors='pt', padding=True, truncation=True, max_length=512)
    with torch.no_grad():
        outputs = bert_model(**inputs)
    embedding = outputs.last_hidden_state[:, 0, :].numpy()

    # Ensure the embedding shape is correct
    if embedding.ndim == 1:
        embedding = embedding.reshape(1, -1)  # Reshape if necessary

    # Predict score
    predicted_score = model.predict(embedding)

    # Convert predicted_score to a scalar
    predicted_score = predicted_score.item() if isinstance(predicted_score, np.ndarray) else predicted_score
    
    return {"predicted_score": round(predicted_score, 2)}
