import joblib
import torch
from transformers import BertTokenizer, BertModel
from sklearn.model_selection import train_test_split,GridSearchCV,RandomizedSearchCV
from xgboost import XGBRegressor
from sklearn.ensemble import RandomForestRegressor  # Import Random Forest
from sklearn.linear_model import LinearRegression  # Import Linear Regression
from tqdm import tqdm
import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error, cohen_kappa_score
from app.preprocess import clean_essay

# Load BERT model and tokenizer
bert_model_name = 'bert-base-uncased'
tokenizer = BertTokenizer.from_pretrained(bert_model_name)
bert_model = BertModel.from_pretrained(bert_model_name)

def get_bert_embeddings(texts):
    """
    Generate BERT embeddings for a list of texts, with tqdm to track progress.
    """
    embeddings = []
    for text in tqdm(texts, desc="Generating BERT Embeddings"):
        inputs = tokenizer([text], return_tensors='pt', padding=True, truncation=True, max_length=512)
        with torch.no_grad():
            outputs = bert_model(**inputs)
        embeddings.append(outputs.last_hidden_state[:, 0, :].numpy())  # Use [CLS] token embedding
    return np.vstack(embeddings)

def quadratic_weighted_kappa(y_true, y_pred):
    """
    Calculate Quadratic Weighted Kappa (QWK) for model evaluation.
    """
    y_pred_rounded = np.round(y_pred).astype(int)
    return cohen_kappa_score(y_true, y_pred_rounded, weights='quadratic')

def train_model():
    # Load dataset
    df = pd.read_csv(r'C:\Users\admin\OneDrive\Desktop\Abdul_Projects\essay-score-predictor\data\learning-agency-lab-automated-essay-scoring-2\train.csv')
    df['cleaned_essay'] = df['full_text'].apply(clean_essay)

    # Split data
    X = df['cleaned_essay'].tolist()
    y = df['score']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # # Generate BERT embeddings for the essays
    # print("Generating BERT embeddings for training data...")
    # X_train_embeddings = get_bert_embeddings(X_train)
    # print("Generating BERT embeddings for test data...")
    # X_test_embeddings = get_bert_embeddings(X_test)

    # import pickle
    # with open('X_train_embeddings.pkl', 'wb') as f:
    #     pickle.dump(X_train_embeddings, f)

    # with open('X_val_embeddings.pkl', 'wb') as f:
    #     pickle.dump(X_test_embeddings, f)
    import pickle

    # Load the X_train_embeddings from the .pkl file
    with open('X_train_embeddings.pkl', 'rb') as f:
        X_train_embeddings = pickle.load(f)

    # Load the X_val_embeddings from the .pkl file
    with open('X_val_embeddings.pkl', 'rb') as f:
        X_test_embeddings = pickle.load(f)

# Now you can use X_train_embeddings and X_val_embeddings as needed in your code

    # Define hyperparameter grids
    param_grids = {
        "XGBoost": {
            'n_estimators': [100, 200, 300],
            'max_depth': [3, 5, 7],
            'learning_rate': [0.01, 0.1, 0.2],
            'subsample': [0.8, 1.0]
        },
        # "Random Forest": {
        #     'n_estimators': [100, 200],
        #     'max_depth': [None, 10, 20],
        #     'min_samples_split': [2, 5, 10],
        #     'min_samples_leaf': [1, 2, 4]
        # },
        "Linear Regression": {
            'fit_intercept': [True, False]
        }
    }

    # Define models
    models = {
        "XGBoost": XGBRegressor(),
        "Linear Regression": LinearRegression()
    }

    # Variables to track the best model and scores
    best_model = None
    best_rmse = float('inf')
    best_qwk = -1

    for name, model in models.items():
        print(f"Training the {name} model...")

        # Perform hyperparameter tuning using RandomizedSearchCV
        random_search = RandomizedSearchCV(
            model, 
            param_distributions=param_grids[name], 
            scoring='neg_root_mean_squared_error', 
            cv=2, 
            n_jobs=-1, 
            verbose=1,
            n_iter=3  # Limit the number of parameter settings tested
        )
        
        # Fit the model on training data
        random_search.fit(X_train_embeddings, y_train)

        # Get the best estimator
        best_estimator = random_search.best_estimator_
        print(f"Best parameters for {name}: {random_search.best_params_}")

        # Evaluate the model on validation set
        print(f"\nEvaluating {name} performance on validation set...")
        y_pred = best_estimator.predict(X_test_embeddings)

        # RMSE evaluation
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        print(f"{name} Validation RMSE: {rmse:.4f}")

        # QWK evaluation (assuming you have a function to calculate QWK)
        qwk = quadratic_weighted_kappa(y_test, y_pred)
        print(f"{name} Validation Quadratic Weighted Kappa: {qwk:.4f}")

        # Save the best model
        if rmse < best_rmse:
            best_rmse = rmse
            best_qwk = qwk
            best_model = best_estimator

    # Final output of the best model
    print(f"\nBest model: {type(best_model).__name__} with RMSE: {best_rmse:.4f} and QWK: {best_qwk:.4f}")


    # Save the best model, tokenizer, and BERT model
    joblib.dump(best_model, 'best_model.pkl')
    joblib.dump(tokenizer, 'tokenizer.pkl')
    joblib.dump(bert_model, 'bert_model.pkl')



def evaluate_on_test_data(test_csv_path):
    # Load the trained model, tokenizer, and BERT model
    model, tokenizer, bert_model = load_model()

    # Load test dataset
    df_test = pd.read_csv(test_csv_path)
    df_test['cleaned_essay'] = df_test['full_text'].apply(clean_essay)

    # Generate BERT embeddings for the test essays
    print("Generating BERT embeddings for test data...")
    X_test = df_test['cleaned_essay'].tolist()
    X_test_embeddings = get_bert_embeddings(X_test)

    # Predict scores for the test dataset
    print("Predicting scores for the test dataset...")
    predicted_scores = model.predict(X_test_embeddings)

    # Evaluate model performance on test data
    print("\nEvaluating model performance on test dataset...")
    
    # RMSE evaluation
    rmse_test = np.sqrt(mean_squared_error(df_test['score'], predicted_scores))
    print(f"Test RMSE: {rmse_test:.4f}")

    # QWK evaluation
    qwk_test = quadratic_weighted_kappa(df_test['score'], predicted_scores)
    print(f"Test Quadratic Weighted Kappa: {qwk_test:.4f}")

    # Save the predictions with actual scores
    df_test['predicted_score'] = predicted_scores
    df_test[['full_text', 'score', 'predicted_score']].to_csv('test_predictions_with_eval.csv', index=False)
    print("\nTest results saved to 'test_predictions_with_eval.csv'")

def load_model():
    model = joblib.load('model.pkl')
    tokenizer = joblib.load('tokenizer.pkl')
    bert_model = joblib.load('bert_model.pkl')
    return model, tokenizer, bert_model
